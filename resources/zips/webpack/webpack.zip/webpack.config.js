module.exports = require('./config/webpack.dev.js');
